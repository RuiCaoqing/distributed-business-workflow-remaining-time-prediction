# import communities.algorithms as cum
# import communities.visualization as cumv
# import numpy
# import matplotlib.pyplot as plt
# from netgraph import Graph, InteractiveGraph
# import networkx
#
# # f=open("BPIC2012_activity.csv","r",encoding="utf-8")
# # f=open("BPIC2017_activity.csv","r",encoding="utf-8")
# f=open("F:\代码\context-sensitive-deep-learning-comparison\code_6_communityPartition\data\ogrinal\BPIC2017_activity_SE_high.csv","r",encoding="utf-8")
# # f=open("yuanshi.csv","r",encoding="utf-8")
# ls=[]
# lx=[]
# ly=[]
# ln=[]
# lis=[]
# ply =set()
# queshiweizhi=[]
# for line in f:
#     ls.append(line)
# lx=ls.copy()
# ls.pop(0)
# ly=ls.copy()
# for n in range(len(ly)):
#     p=str(lx[n]).strip('\n')+' '+str(ly[n]).strip('\n')
#     ln.append(p)
# lw=ln.copy()
# ljh=set(lw)
# # print(ljh)
# zidian=dict()
# count=0
# for i in ljh:
#     num=0
#     for j in ln:
#         nx = str(i).split(' ')
#         ny = str(j).split(' ')
#         if i==j :
#             num+=1
#     zidian[i]=num
#
#
# for q in zidian:
#     qx=q.split(' ')
#     if not(ord(qx[0]) in ply):
#         ply.add(ord(qx[0]))
#     if not(ord(qx[1]) in ply):
#         ply.add(ord(qx[1]))
# # plt1=sorted(ply)
# # print(plt1)
# print(ply)
# jvzhensize = max(ply)-64
# print(jvzhensize)
# for i in range(jvzhensize):
#     if ((i+65) not in ply):
#         queshiweizhi.append(i)
# print(queshiweizhi)
# jvzhen = numpy.zeros((jvzhensize,jvzhensize))
#
# fp=open("IO.txt","w",encoding="utf-8")
# for line in zidian:
#     np=str(line).split(' ')
#     fp.write(str(ord(np[0])-65)+' '+str(ord(np[1])-65)+' '+str(zidian[line])+'\n')
#     hzb = int(ord(np[0])-65)
#     zzb = int(ord(np[1])-65)
#     jvzhen[(hzb, zzb)] = int(zidian[line])
# f.close()
# print(jvzhen.shape)
# temptuple=tuple(queshiweizhi)
# jvzhen1=numpy.delete(numpy.delete(jvzhen,temptuple,axis=0),temptuple,axis=1)
# print(jvzhen1.shape)
# print(zidian)
#
#
# communities, frames =cum.louvain_method(jvzhen1)
# # print(communities)
#
# #可视化
# # create a modular graph
# communitiessize=[]
# for oneset in communities:
#     setsize=len(oneset)
#     if setsize==1:
#         setsize=2
#     communitiessize.append(setsize)
# # print(communitiessize)
# gra = networkx.random_partition_graph(communitiessize, 1, 1)
# print("okok")
# # since we created the graph, we know the best partition:
# node_to_community = dict()
# node = 0
# for community_id, size in enumerate(communitiessize):
#     for _ in range(size):
#         node_to_community[node] = community_id
#         node += 1
#
# # # alternatively, we can infer the best partition using Louvain:
# # from community import community_louvain
# # node_to_community = community_louvain.best_partition(g)
#
# community_to_color = {
#     0 : 'tab:blue',
#     1 : 'tab:orange',
#     2 : 'tab:green',
#     3 : 'tab:red',
#     4 : 'tab:pink',
#     5 : 'tab:green',
#     6 : 'tab:purple',
#     7 : 'tab:cyan',
#     8 : 'k',
#     9 : '#ff00ff',
#     10 : '#99ff66',
#     11 : '#8C7853',
# }
# community_to_shape = {
#     0 : 'o',
#     1: '^',
#     2 : '<',
#     3: 'v',
#     4: '>',
#     5: 's',
#     6 : 'd',
#     7 : 'p',
#     8 : 'h',
#     9 : '8',
#     10 : '>',
#     11 : '>',-``
# }-``
#
# # community_to_shape1 = {
# #     '0': 'o',
# #     '1': '^',
# #     '2': '+',
# #     '3': '*',
# #     '4': '.',
# #     '5': 'x',
# #     '6' : 's',
# #     '7': 'd',
# #     '8': 'p',
# #     '9': 'h',
# #     '10' : 'h',
# #     '11': 'h',
# # }
# #
# # markers = {'.': 'point', ',': 'pixel', 'o': 'circle', 'v': 'triangle_down', '^': 'triangle_up', '<': 'triangle_left', '>': 'triangle_right', '1': 'tri_down', '2': 'tri_up', '3': 'tri_left', '4': 'tri_right', '8': 'octagon', 's': 'square', 'p': 'pentagon', '*': 'star', 'h': 'hexagon1', 'H': 'hexagon2', '+': 'plus', 'x': 'x', 'D': 'diamond', 'd': 'thin_diamond', '|': 'vline', '_': 'hline', 'P': 'plus_filled', 'X': 'x_filled', 0: 'tickleft', 1: 'tickright', 2: 'tickup', 3: 'tickdown', 4: 'caretleft', 5: 'caretright', 6: 'caretup', 7: 'caretdown', 8: 'caretleftbase', 9: 'caretrightbase', 10: 'caretupbase', 11: 'caretdownbase', 'None': 'nothing', None: 'nothing', ' ': 'nothing', '': 'nothing'}
#
#
# node_color = {node: community_to_color[community_id] for node, community_id in node_to_community.items()}
# print(node_color)
# # shapelist=[]
# # for node, community_id in node_to_community.items():
# #     shapelist.append(community_id)
# # print(shapelist)
# node_shape1 = {node1: community_to_shape[community_id1] for node1, community_id1 in node_to_community.items()}
# # for node, community_id in node_shape.items():
# #     print(type(community_id))
# #     print(community_id)
# print(node_shape1)
# Graph(gra,
#       node_color=node_color,node_edge_width=1, edge_alpha=0.1,node_shape=node_shape1,
#       node_layout='community', node_layout_kwargs=dict(node_to_community=node_to_community),
#       edge_layout='bundled', edge_layout_kwargs=dict(k=2000),
# )
#
# plt.savefig('./img/BPIC2017_activity_SE_high.png')
# plt.savefig('./img/BPIC2017_activity_SE_high.eps')#  ####################################################################################
# plt.savefig('./img/BPIC2017_activity_SE_high.svg')#  ####################################################################################
# # plt.savefig('./img/主成分分析/2017A8bcolorLSTM_PCR.svg', format='svg', dpi=1000)#  ####################################################################################
# # plt.savefig('./img/主成分分析/2017A8bcolorLSTM_PCR.png', format='pdf', dpi=1000)