
from GRU import GRU
from LSTM import LSTM
from input_data_ActivityPartition import InputData
from collections import deque
import numpy as np
import os
import torch
import torch.nn as nn
import gensim
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader, Dataset, TensorDataset
from math import sqrt
from numpy import *
from collections import OrderedDict

SEED = 1
torch.manual_seed(SEED)
torch.cuda.manual_seed(SEED)
np.random.seed(SEED)

import datetime
import time

def train(data_address, data_name, vector_address=None, embd_dimension=2, embd_dimension_suffix=5, hidden_dim_suffix=2,
          train_splitThreshold=0.7,
          time_unit='day', batch_size=9,
          loss_type='L1Loss', optim_type='Adam', model_type='GRU', hidden_dim=5,
          train_type='iteration', n_layer=1, dropout=1, max_epoch_num=10, learn_rate_min=0.0001, path_length=8,
          train_record_folder='./train_record/', model_save_folder='./model/', result_save_folder='./result/',
          ts_type='set', inputstring=None):
    # 初始化数据
    out_size = 1
    learn_rate = 0.01
    epoch = 0
    learn_rate_backup = 0.01
    learn_rate_down_backup = 0.001
    loss_deque = deque(maxlen=20)
    loss_change_deque = deque(maxlen=30)
    print('User Model ' + model_type + " To Start Experience.")

    data = InputData(data_address, embd_dimension=embd_dimension)
    print("InputData Finish")

    data.encodeEvent()
    print("EncodeEvent Finish")
    data.encodeTrace()
    print("EncodeTrace Finish")
    # 通过设置固定的随机数种子以获取相同的训练集和测试集,timeEmbedding=data.timeEmbedding
    data.splitData(train_splitThreshold)
    print("SplitData Finish")
    train_singlePrefixData12, train_labelPrefixData2, test_singlePrefixData12, test_labelPrefixData2 \
        = data.initBatchData_Prefix(time_unit)
    print("InitBatchData Finish")
    # data.generateSingleLengthBatch(batch_size)
    train_singlePrefixData1 = {}
    train_singlePrefixData = {}
    train_labelPrefixData1 = {}
    test_singlePrefixData1 = {}
    test_singlePrefixData = {}
    test_labelPrefixData1 = {}

    temp1 = []
    temp2 = []
    temp3 = []
    temp4 = []

    activityindict = []
    for line in train_singlePrefixData12:
        activityindict.append(line)
    print("活动共有如下几种：")
    print(activityindict)
    print("请输入分组，组内以空格间隔，组间以冒号间隔，例如：1 2 3:4 5")
    inputstr = inputstring
    strlist = inputstr.strip('\n').split(':')
    for i in strlist:
        templist = i.split(' ')
        for j in templist:
            for m in train_singlePrefixData12[int(j)]:
                temp1.append(m)
            for m in train_labelPrefixData2[int(j)]:
                temp2.append(m)
            for m in test_singlePrefixData12[int(j)]:
                temp3.append(m)
            for m in test_labelPrefixData2[int(j)]:
                temp4.append(m)
        train_singlePrefixData1[i] = temp1.copy()
        train_labelPrefixData1[i] = temp2.copy()
        test_singlePrefixData1[i] = temp3.copy()
        test_labelPrefixData1[i] = temp4.copy()
        temp1.clear()
        temp2.clear()
        temp3.clear()
        temp4.clear()
    for item in train_singlePrefixData1.items():
        length = [len(sublist) for sublist in train_singlePrefixData1[item[0]]]
        # print("每个序列的长度为：\n", length)
        maxLen_trainprefix = max(length)
        train_singlePrefixData[item[0]] = [sublist + [0] * (maxLen_trainprefix - len(sublist)) for sublist in
                                           train_singlePrefixData1[item[0]]]
    for item in test_singlePrefixData1.items():
        length = [len(sublist) for sublist in test_singlePrefixData1[item[0]]]
        # print("每个序列的长度为：\n", length)
        maxLen_trainprefix = max(length)
        test_singlePrefixData[item[0]] = [sublist + [0] * (maxLen_trainprefix - len(sublist)) for sublist in
                                          test_singlePrefixData1[item[0]]]
    # 初始化模型
    if model_type == 'LSTM':
        model = LSTM(vocab_size=data.vocab_size, embedding_dim=embd_dimension, hidden_dim=hidden_dim, out_size=out_size,
                     batch_size=batch_size, n_layer=n_layer, dropout=dropout, embedding=data.embedding)

    elif model_type == 'GRU':
        model = GRU(vocab_size=data.vocab_size, embedding_dim=embd_dimension, hidden_dim=hidden_dim, out_size=out_size,
                    batch_size=batch_size, n_layer=n_layer, dropout=dropout, embedding=data.embedding)



    if loss_type == 'L1Loss':
        criterion = nn.L1Loss()
    elif loss_type == 'MSELoss':
        criterion = nn.MSELoss()

    optimizer = optim.Adam(model.parameters(), lr=learn_rate)

    # 开始训练


    model_MLP_Dict = {}
    model_time_Dict = {}
    model_prediction_time = {}


    model = LSTM(vocab_size=data.vocab_size, embedding_dim=embd_dimension, hidden_dim=hidden_dim,
                 out_size=out_size,
                 batch_size=batch_size, n_layer=n_layer, embedding=data.embedding)

    output1 = open('./output/' + data_name + "_" + model_type + "_ActivityCluster_Transfer.csv", "a", encoding='utf-8')
    output1.write("MSE, MAE, RMSE, Total_model_prediction_time\n")

    output2 = open('./output/' + data_name + "_" + model_type + "_single_ActivityCluster_Transfer.csv", "a", encoding='utf-8')
    output2.write("ID, MSE, MAE, RMSE, Each_model_prediction_time \n")

    time_list = []
    total_prediction_time = 0


    trans = model.state_dict()
    for item in train_singlePrefixData.items():
        # print(train_singlePrefixData[item[0]])

        start_time = datetime.datetime.now()
        start_time = datetime.datetime.strftime(start_time, '%Y-%m-%d %H:%M:%S')
        start_time = time.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        print('start_time:       ', start_time)
        start_timestamp = int(time.time())
        print('start_timestamp:       ', start_timestamp)




        tensor_x = torch.from_numpy(np.array(train_singlePrefixData[item[0]], dtype=np.int64))

        tensor_y = torch.from_numpy(np.array(train_labelPrefixData1[item[0]], dtype=np.float32))
        trainPre_dataset = torch.utils.data.TensorDataset(tensor_x, tensor_y)

        trainPre_dataset_loader = DataLoader(trainPre_dataset, batch_size=9, drop_last=True, shuffle=True)

        model = LSTM(vocab_size=data.vocab_size, embedding_dim=embd_dimension, hidden_dim=hidden_dim,
                     out_size=out_size,
                     batch_size=batch_size, n_layer=n_layer, embedding=data.embedding)
        model.load_state_dict(trans)
        #     训练
        for enpoch in range(10):
            total_loss = torch.FloatTensor([0])
            for i, (input, target) in enumerate(trainPre_dataset_loader):
                optimizer.zero_grad()
                input = np.array(input)

                target = np.array([[t] for t in target])

                input = Variable(torch.LongTensor(input))

                target = Variable(torch.LongTensor(target))
                # print(input, target)
                target = target.float()
                output = model(input)
                loss = criterion(output, target)
                # optimizer.zero_grad()
                loss.backward(retain_graph=True)
                optimizer.step()
                total_loss += loss.data
        trans = model.state_dict()
        model_MLP_Dict[item[0]] = model

        model_time_Dict[item[0]] = int(time.time())
        print('model_time_Dict[item[0]]:       ', model_time_Dict[item[0]])

        model_prediction_time[item[0]] = model_time_Dict[item[0]] - start_timestamp
        print('model_prediction_time[item[0]:       ', model_prediction_time[item[0]])

        time_list.append(model_prediction_time[item[0]])

    for ele in range(0, len(time_list)):
        total_prediction_time = total_prediction_time + time_list[ele]

        # print("列表元素之和为: ", total)
    print('model_time_Dict:       ', model_time_Dict)
    print('model_prediction_time:       ', model_prediction_time)
    print(0)
    #  开始测试
    predList = []
    realList = []
    # output1 = open('./output/' + data_name +  "_" + model_type +  "_ActivityCluster_Transfer.csv", "a", encoding='utf-8')
    # output1.write("MSE, MAE, RMSE\n")
    #
    # output2 = open('./output/' + data_name +  "_" + model_type +  "_single_ActivityCluster_Transfer.csv", "a", encoding='utf-8')
    # output2.write("ID, MSE, MAE, RMSE \n")

    # test_singlePrefixData = OrderedDict()
    # test_labelPrefixData1 = OrderedDict()
    #
    #
    # for activity_index in activity_list:
    #     if test_singlePrefixData1.get(activity_index) is not None:  # python2用的是row.has_key(key)
    #         test_singlePrefixData[activity_index] = test_singlePrefixData1.get(activity_index)
    #         test_labelPrefixData1[activity_index] = test_labelPrefixData.get(activity_index)

    for item in test_singlePrefixData.items():
        tensor_x = torch.from_numpy(np.array(test_singlePrefixData[item[0]]))

        tensor_y = torch.from_numpy(np.array(test_labelPrefixData1[item[0]]))
        testPre_dataset = torch.utils.data.TensorDataset(tensor_x, tensor_y)

        testPre_dataset_loader = DataLoader(testPre_dataset, batch_size=9, drop_last=True, shuffle=True)

        singlepred = []
        singlereal = []
        modelLinear = model_MLP_Dict[item[0]]  # 取出训练后的深度模型进行测试
        print("===================")
        #
        for i, (input3, target3) in enumerate(testPre_dataset_loader):
            input3 = np.array(input3)
            input3 = Variable(torch.LongTensor(input3))

            target3 = list(target3)
            prediction = modelLinear(input3)
            predList += [pdic.item() for pdic in prediction]
            print(0)
            realList += target3
            singlepred += [pdic.item() for pdic in prediction]
            singlereal += target3

        if len(singlepred) != 0:
            MSE = computeMSE(singlereal, singlepred)
            MAE = computeMAE(singlereal, singlepred)


            output2.write(str(model_time_Dict[item[0]]) + '\n')
            output2.write(str(model_prediction_time[item[0]]) + '\n')
            output2.write(
                str(item[0]) + ',   ' + str(float(MSE)) + ',   ' + str(float(MAE)) + ',   ' + str(
                    float(MAE)) + ',   ' + str(model_prediction_time[item[0]]) + '\n')
            # output2.write(str(model_prediction_time[item[0]]) + '\n')

        end_time = datetime.datetime.now()
        end_time = datetime.datetime.strftime(end_time, '%Y-%m-%d %H:%M:%S')
        print('end_time:       ', end_time)
        end_timestamp = int(time.time())
        print('end_timestamp:       ', end_timestamp)

    MSE = computeMSE(realList, predList)
    MAE = computeMAE(realList, predList)
    RMSE = sqrt(MSE)


    output1.write("end_time:," + str(end_time) + '\n')
    output1.write("end_timestamp:," + str(int(end_timestamp)) + '\n')
    output1.write("Activity_Clustering_" + model_type + "_____________" + "totalMSE:," + str(float(MSE)) + '   ')
    output1.write("totalMAE:," + str(float(MAE)) + '   ')
    output1.write("totalRMSE:," + str(float(RMSE)) + '   ')
    output1.write("total_prediction_time:," + str(int(total_prediction_time)) + '\n')

    print("===========total===============")
    print(MSE, MAE, RMSE)

    print('total_prediction_time:         ', total_prediction_time)


def computeMAE(list_a, list_b):
    MAE_temp = []
    for num in range(len(list_a)):
        MAE_temp.append(abs(list_a[num] - list_b[num]))
    MAE = sum(MAE_temp) / len(list_a)
    return MAE


def computeMSE(list_a, list_b):
    MSE_temp = []
    for num in range(len(list_a)):
        MSE_temp.append((list_a[num] - list_b[num]) * (list_a[num] - list_b[num]))
    MSE = sum(MSE_temp) / len(list_a)
    return MSE


def computeTOTAL(list_a, list_b):
    TOTAL_temp = []
    for num in range(len(list_a)):
        TOTAL_temp.append(abs(list_a[num] - list_b[num]))
    TOTAL = sum(TOTAL_temp)
    return TOTAL


def computeMEAN(list_a, list_b):
    MEAN_temp = []
    for num in range(len(list_a)):
        MEAN_temp.append(abs(list_a[num] - list_b[num]))
    MEAN = sum(MEAN_temp) / len(list_a)
    return MEAN


if __name__ == '__main__':
    # 1. BPIC2012_activity_SE_high (day)    2. BPIC2012_activity_SE_high (day)        3. Chuan (minute)      4. Cross_Hospital (minute)
    # 5. Food  (minute)      6.  Medicine (minute)               7. SepsisCases_activity_SE_high (day)
    data_address = 'F:\代码\context-sensitive-deep-learning-comparison\code_6_communityPartition\data\ogrinal\Chuan.csv'#*********************************************
    embd_dimension = 2
    train_splitThreshold = 0.7
    time_unit = 'hour'#***********************************************************************************************************************************************
    data = InputData(data_address, embd_dimension=embd_dimension)
    data.encodeEvent()
    # print(0)
    data.encodeTrace()
    # 通过设置固定的随机数种子以获取相同的训练集和测试集,timeEmbedding=data.timeEmbedding
    data.splitData(train_splitThreshold)
    train_singlePrefixData1, train_labelPrefixData, test_singlePrefixData1, test_labelPrefixData \
        = data.initBatchData_Prefix(time_unit)
    activityindict = []
    for line in train_singlePrefixData1:
        activityindict.append(line)
    print("活动共有如下几种：")
    print(activityindict)
    print("请输入分组，组内以空格间隔，组间以冒号间隔，例如：1 2 3:4 5")




    # 2 18 3 4 5 6 7 8 9 10:11 17:12 13 14 15                                               # BPIC2012_activity_SE_high********************************************

    # 21 18 22:2 3 4 5 6 7 8 9:10 11 12 13 14 15 16:19 17                                   # BPIC2017_activity_SE_high  4****************************************
    # 21 18 22:2 3 4 5 6 7:8 9:10 11 12 13 14 15 16:19 17           5

    # 4 7 2:3 5 6 8 9 11 12 13 14 15 18 21 25 26 28 29:27 10 16 17 19 20 22 23 24           # Chuan.csv   3*******************************************************

    # 2 3 4 6 7 8:9 5 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24:25 26 28 27:29 30 31      # Cross_Hospital.csv 4************************************************

    # 2 3 4 5 6 7 8 10 11 13 15 16 25 26 18:9 12 14 17 19 20:21 22 23 24                    # Food.csv 3    25 activity********************************************

    # 2 3 1 4:5 6 7 8 9 10 15 17 18:11 12 13 14 16 19 20 21:22                              # Medicine.csv 4 22 activity********************************************

    # 2 3 4 11 5 6 7 8:9 13 12 10                                                           # SepsisCases_activity_SE_high********************************************
    # 2 3 4 11 5 6 7 8:9 13 12:10

    # 7 17 21 22:2 3 4 5 8 9 10:11 6 12 13  # BPI2018_activity_SE_high_39-45.csv   3类    15 activity************************************


    inputstr1 = input()
    train(data_address=data_address,
          data_name='Chuan', vector_address=None, model_type='GRU',embd_dimension=embd_dimension,#*******************************************************************
          embd_dimension_suffix=5, hidden_dim_suffix=2, train_splitThreshold=train_splitThreshold,
          time_unit=time_unit, batch_size=9,
          loss_type='L1Loss', optim_type='Adam', inputstring=inputstr1)