from BiGRUAtt_BiGRUAtt import BiGRUAtt_BiGRUAtt
from BiGRUAtt import BiGRUAtt
from BiGRU import BiGRU
from LSTMvarient import LSTM
from GRU import GRU
from input_data_ActivityPartition import InputData
from collections import deque
import numpy as np
import os
import torch
import torch.nn as nn
import gensim
import torch.optim as optim
from torch.autograd import Variable
from torch.utils.data import DataLoader, Dataset, TensorDataset
from math import sqrt
from numpy import *
from collections import OrderedDict

data_address='/Users/caorui/Desktop/code_6_communityPartition/data/ogrinal/Loan_application_Configuration1.csv'
embd_dimension=2
train_splitThreshold=0.7
time_unit='day'
finaldict_train_singlePrefixData1={}
finaldict_train_labelPrefixData={}
finaldict_test_singlePrefixData1={}
finaldict_test_labelPrefixData={}
# finallist_train_singlePrefixData1=[]
# finallist_train_labelPrefixData=[]
# finallist_test_singlePrefixData1=[]
# finallist_test_labelPrefixData=[]
temp1=[]
temp2=[]
temp3=[]
temp4=[]

data = InputData(data_address, embd_dimension=embd_dimension)
print("InputData Finish")

data.encodeEvent()
print("EncodeEvent Finish")
data.encodeTrace()
print("EncodeTrace Finish")
# 通过设置固定的随机数种子以获取相同的训练集和测试集,timeEmbedding=data.timeEmbedding
data.splitData(train_splitThreshold)
print("SplitData Finish")
train_singlePrefixData1, train_labelPrefixData, test_singlePrefixData1, test_labelPrefixData \
    = data.initBatchData_Prefix(time_unit)
# print(train_singlePrefixData1)
# print(train_labelPrefixData)
# print(test_singlePrefixData1)
# print(test_labelPrefixData)
activityindict=[]
for line in train_singlePrefixData1:
    activityindict.append(line)
print("活动共有如下几种：")
print(activityindict)
print("请输入分组，组内以空格间隔，组间以冒号间隔，例如：1 2 3:4 5")
# inputstr=input()
inputstr=input()
strlist=inputstr.strip('\n').split(':')
for i in strlist:
    templist=i.split(' ')
    for j in templist:
        for m in train_singlePrefixData1[int(j)]:
            temp1.append(m)
        for m in train_labelPrefixData[int(j)]:
            temp2.append(m)
        for m in test_singlePrefixData1[int(j)]:
            temp3.append(m)
        for m in test_labelPrefixData[int(j)]:
            temp4.append(m)
    finaldict_train_singlePrefixData1[i]=temp1.copy()
    finaldict_train_labelPrefixData[i]=temp2.copy()
    finaldict_test_singlePrefixData1[i]=temp3.copy()
    finaldict_test_labelPrefixData[i]=temp4.copy()
    temp1.clear()
    temp2.clear()
    temp3.clear()
    temp4.clear()
print(finaldict_train_singlePrefixData1)
print(finaldict_train_labelPrefixData)
print(finaldict_test_singlePrefixData1)
print(finaldict_test_labelPrefixData)