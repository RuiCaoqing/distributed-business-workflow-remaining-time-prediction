# coding: utf-8
import numpy as np
import torch
import torch.nn as nn
import gensim
import torch.optim as optim
from torch.autograd import Variable
import torch.nn.functional as F
from datetime import datetime
import os
# import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from math import sqrt
import random
from functools  import reduce
from torch.nn.utils.rnn import pack_padded_sequence
from torch.nn.utils.rnn import pad_packed_sequence

random.seed = 13


class InputData():   # 前缀的处理，也可以处理后缀
    def __init__(self, data_address, embd_dimension=2):
        self.embedding = None
        self.timeEmbedding = None
        self.ogrinal_data = list()
        self.orginal_trace = list()
        self.encode_trace = list()
        self.train_dataset = list()
        self.test_dataset = list()
        self.train_mixLengthData = list()
        self.test_mixLengthData = list()
        self.event2id = dict()
        self.id2event = dict()
        self.train_batch_mix = list()
        self.test_batch_mix = list()
        self.train_singleLengthData = dict()
        self.test_singleLengthData = dict()
        self.train_batch = dict()
        self.test_batch = dict()
        self.train_batch_single = dict()
        self.test_batch_single = dict()

        self.vocab_size = 0
        self.train_maxLength = 0
        self.test_maxLength = 0
        self.embd_dimension = embd_dimension
        self.initData(data_address)
    # 构建id2event event2id
    def initData(self, data_address):
        # print("in initData")
        id2event = dict()
        event2id = dict()
        orginal_trace = list()
        record = list()
        trace_temp = list()
        with open(data_address, 'r', encoding='utf-8') as f:
            # 数据第一行为表头
            # f = data_address
            next(f)
            lines = f.readlines()
            for line in lines:
                record.append(line)
        flag = record[0].split(',')[0]
        for line in record:
            # print(line)
            line = line.replace('\r', '').replace('\n', '')
            line = line.split(',')
            # 构造id2event and event2id
            if line[1] not in event2id.keys():
                index = len(event2id)
                id2event[index] = line[1]
                event2id[line[1]] = index
            if line[0] == flag:
                trace_temp.append([line[1], line[2]])
            else:
                flag = line[0]
                if len(trace_temp) > 0:
                    orginal_trace.append(trace_temp.copy())
                trace_temp = list()
                trace_temp.append([line[1], line[2]])
        self.id2event = id2event
        self.event2id = event2id
        self.vocab_size = len(self.event2id)
        self.ogrinal_data = record
        #CaseID = 2 ：[['1_2', '2012-04-03 16:55:38'], ['8_8', '2012-04-03 16:55:53'], ['6_0', '2012-04-05 17:15:52']]
        self.orginal_trace = orginal_trace
        # 生成中间文件
        # print(0)

    # 加载预训练的词向量
    def encodeEvent(self):
        event2id = dict()
        id2event = dict()

        for line in self.ogrinal_data:
            line = line.replace('\r', '').replace('\n', '')
            line = line.split(',')
            try:
                event2id[line[1]] = event2id[line[1]]
                id2event[event2id[line[1]]] = id2event[event2id[line[1]]]
            except KeyError as ke:

                event2id[line[1]] = len(event2id)
                id2event[len(id2event)] = line[1]
                # event2id[line[1]] = line[1]
                # id2event[line[1]] = line[1]
        self.vocab_size = len(event2id)
        self.embedding = nn.Embedding(self.vocab_size + 1, self.embd_dimension, padding_idx=self.vocab_size)
        print(0)
    def encodeTrace(self):
        encode_trace = list()
        max = 0
        for line in self.orginal_trace:
            trace_temp = list()
            for line2 in line:
                trace_temp.append([self.event2id[line2[0]], line2[1]])
            if len(trace_temp) > max:
                max = len(trace_temp)
            encode_trace.append(trace_temp.copy())
        self.max = max
        self.encode_trace = encode_trace
        # print(0)
    # 分割训练集和测试集 7:3
    def splitData(self, train_splitThreshold=0.7):
        # print(len(self.encode_trace))
        self.train_dataset, self.test_dataset = train_test_split(self.encode_trace, train_size=train_splitThreshold,
                                                                 test_size=1 - train_splitThreshold, random_state=123)
    # 处理train or test 生成相应长度single以及mix的list
    def initBatchData_Prefix(self, time_unit):     # 训练集和测试集分别生成前缀集和后缀集
        if time_unit == 'second':
            time_unit = 1
        elif time_unit == 'minute':
            time_unit = 60
        elif time_unit == 'hour':
            time_unit = 60 * 60
        elif time_unit == 'day':
            time_unit = 24 * 60 * 60
        elif time_unit == 'month':
            time_unit = 30 * 24 * 60 * 60
        train_singlePrefixData = dict()
        train_singlePrefixData1 = {}
        train_labelPrefixData = dict()

        test_singlePrefixData = dict()
        test_singlePrefixData1 = dict()
        test_labelPrefixData = dict()

        train_maxLength = 0
        test_maxLength = 0

        for line in self.train_dataset:
            train_prefix_temp = list()
            for index,line_event in enumerate(line):
                train_prefix_temp.append(line_event[0])   # 每条前缀的生成& len(train_prefix_temp)< len(train_prefix_temp) + len(train_suffix_temp)


                if len(train_prefix_temp) > train_maxLength:
                    train_maxLength = len(train_prefix_temp)
                target_time = abs((datetime.strptime(str(line_event[1]), '%Y-%m-%d %H:%M:%S') - datetime.strptime(str(line[-1][1]),
                                                     '%Y-%m-%d %H:%M:%S')).total_seconds() / time_unit)

                if len(train_prefix_temp) > 2 : # 保证了前缀的长度>=3。

                    try:
                        train_singlePrefixData[train_prefix_temp[-1]].append(train_prefix_temp.copy())
                        train_labelPrefixData[train_prefix_temp[-1]].append(target_time)
                    except BaseException as e:
                        train_singlePrefixData[train_prefix_temp[-1]] = list()
                        train_labelPrefixData[train_prefix_temp[-1]] = list()
                        # train_singlePrefixData[train_prefix_temp[-1]].append((train_prefix_temp.copy(),target_time))
                        train_singlePrefixData[train_prefix_temp[-1]].append(train_prefix_temp.copy())
                        train_labelPrefixData[train_prefix_temp[-1]].append(target_time)




        for line1 in self.test_dataset:
            test_prefix_temp = list()
            for index, line_event in enumerate(line1):
                test_prefix_temp.append(line_event[0])  # 每条前缀的生成
                # if index <= len(line):                    # 对应的每条后缀的生成
                test_suffix_temp = []
                for event_suffix in line1[index + 1:]:
                    test_suffix_temp.append(event_suffix[0])
                # print(0)
                if len(test_prefix_temp) > test_maxLength:
                    test_maxLength = len(test_prefix_temp)
                target_time = abs((datetime.strptime(str(line_event[1]), '%Y-%m-%d %H:%M:%S') - datetime.strptime(
                    str(line1[-1][1]), '%Y-%m-%d %H:%M:%S')).total_seconds() / time_unit)
                if len(test_prefix_temp) > 2:
                    try:
                        # test_singlePrefixData[test_prefix_temp[-1]].append((test_prefix_temp.copy(), target_time))
                        test_singlePrefixData[test_prefix_temp[-1]].append(test_prefix_temp.copy())
                        test_labelPrefixData[test_prefix_temp[-1]].append(target_time)
                    except BaseException as e:
                        test_singlePrefixData[test_prefix_temp[-1]] = list()
                        test_labelPrefixData[test_prefix_temp[-1]] = list()
                        # test_singlePrefixData[test_prefix_temp[-1]].append((test_prefix_temp.copy(), target_time))
                        test_singlePrefixData[test_prefix_temp[-1]].append(test_prefix_temp.copy())
                        test_labelPrefixData[test_prefix_temp[-1]].append(target_time)

        # print(0) #
        self.train_singlePrefixData = train_singlePrefixData
        self.train_labelPrefixData = train_labelPrefixData


        self.test_singlePrefixData = test_singlePrefixData
        self.test_labelPrefixData = test_labelPrefixData



        for item in self.train_singlePrefixData.items():

            length = [len(sublist) for sublist in self.train_singlePrefixData[item[0]]]
            # print("每个序列的长度为：\n", length)
            maxLen_trainprefix = max(length)
            train_singlePrefixData1[item[0]]= [sublist + [0] * (maxLen_trainprefix - len(sublist)) for sublist in train_singlePrefixData[item[0]]]


        for item in self.test_singlePrefixData.items():
            length = [len(sublist) for sublist in self.test_singlePrefixData[item[0]]]
            maxLen_testprefix = max(length)
            test_singlePrefixData1[item[0]] = [sublist + [0] * (maxLen_testprefix - len(sublist)) for sublist in
                                                test_singlePrefixData[item[0]]]


        return train_singlePrefixData1, train_labelPrefixData, test_singlePrefixData1, test_labelPrefixData




# if __name__ == '__main__':
#     data_address = "/Users/caorui/Desktop/code_6_communityPartition/data/ogrinal/Loan_application_Configuration1.csv"
#     train_splitThreshold = 0.7
#     data = InputData(data_address, embd_dimension = 2)
#     # # 构建embedding
#     data.encodeEvent()
#     data.encodeTrace()
#     data.splitData()
#     # data.initBatchData_PrefixOrSuffix('day')

